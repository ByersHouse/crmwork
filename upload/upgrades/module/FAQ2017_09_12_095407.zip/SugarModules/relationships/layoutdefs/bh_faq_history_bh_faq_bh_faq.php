<?php
 // created: 2017-09-12 09:54:04
$layout_defs["bh_faq"]["subpanel_setup"]['bh_faq_history_bh_faq'] = array (
  'order' => 100,
  'module' => 'bh_faq_history',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_BH_FAQ_HISTORY_BH_FAQ_FROM_BH_FAQ_HISTORY_TITLE',
  'get_subpanel_data' => 'bh_faq_history_bh_faq',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
