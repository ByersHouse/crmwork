<?php
// created: 2017-09-12 09:54:05
$dictionary["bh_faq"]["fields"]["bh_faq_history_bh_faq"] = array (
  'name' => 'bh_faq_history_bh_faq',
  'type' => 'link',
  'relationship' => 'bh_faq_history_bh_faq',
  'source' => 'non-db',
  'module' => 'bh_faq_history',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BH_FAQ_HISTORY_BH_FAQ_FROM_BH_FAQ_HISTORY_TITLE',
);
