<?php
// created: 2017-09-15 09:10:26
$dictionary["bh_scripts"]["fields"]["bh_scripts_leadership_recommend_bh_scripts"] = array (
  'name' => 'bh_scripts_leadership_recommend_bh_scripts',
  'type' => 'link',
  'relationship' => 'bh_scripts_leadership_recommend_bh_scripts',
  'source' => 'non-db',
  'module' => 'bh_Scripts_leadership_recommend',
  'bean_name' => false,
  'vname' => 'LBL_BH_SCRIPTS_LEADERSHIP_RECOMMEND_BH_SCRIPTS_FROM_BH_SCRIPTS_LEADERSHIP_RECOMMEND_TITLE',
);
