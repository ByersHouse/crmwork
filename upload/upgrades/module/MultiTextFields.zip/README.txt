[ENGLISH]->[RUSSIAN]
Module for additional functionality for the fields with textfields.
 
1) Description
The module allows you to dynamically add any number of phone numbers to any records,
as well as tag them with additional attributes such as: the main, do not call, personal, mobile, work, fax.
The module is designed to fully upgrade safe style with multilanguage support (included in the kit Russian and English version)

Attributes can be edited through the administrative part of the SugarCRM: editor combo box.
The options are stored in the combo box: phone_type_dom. Editing the combo box completely in the style of SugarCRM.

The list (listview) shows only the main room, if the main number is not specified, then the first.
 
2) Innovation in a retrieval system,
For this type of field solved the problem with a phone number search,
because Phones may be recorded in different formats by different users
Example: +1 080 354-456-456, 38050-432 432 654,
in the standard version of the search is complicated by phone.
This version is stored separately in the same phone number with remote separators of all types,
the user is now free to seek these numbers without matching delimiters,
ie, there is now room on request 354456456, 050432432654, with whatever separators it does not exist in the original,
while you can just as well find its original version and delimited 38050-432 432 654.
 
Keep in mind that since we kept a few rooms in a single cell,
as well as to be able to search by phone number without country code and city
in the search bar is necessary to use the% symbol to the left and to the right to search for the occurrence of a substring.
For example: 354456456%%%% 432 654 38050-432 etc.
 
If the version in the line pointing% are not satisfied, you can optionally configure the search by entering the default substring for all fields,
for it is in the file: /include/SearchForm/SearchForm2.php,
change the line (eg line 2!)
$ Where. = $ Db_field. "Like '". $ Field_value $ like_char.. "'";
on
$ Where. = $ Db_field. "Like '". $ Like_char $ field_value $ like_char... "'";
 
In SugarCRM 6.0. This line number 723 and 727
 
3) The principle of operation of the module
Since the module was developed as upgrade safe solution for any module
the most simple embodiment was chosen, storing all data in a single cell.
This storage like a storage option MultiEnum values ​​in the CLD,
where as the separator also acts ^ ^ between the data.
 
When you save the data "compressed" into a single value, the extraction of "decompressed".
 
4) Install
The module is fitted as standard across the module loader in the administrative part of SugarCRM.
Full upgrade safe compatibility with SugarCRM versions above 5.5.
In theory compatible with any version since 5.0. (Not tested)
 
5) Using
After installing a new type of field ExtraPhone appears in the studio (in the Russian version of "advanced phone").
Any module can add a field type.
Also then this field can be added to any layout of the form: Edit, View, Search, List.
 
6) Compatible with the Custom user modules (custom modules)
Full compatibility with the Custom modules.
 
7) Work through Soap
You can work with the data type of the field and through the soap protocol, or any module operating over soap protocol.
In this case, "data unclamping" is programmed in the module, which will use this field.
Implemented in two lines using explode ( "^, ^", $ array), and explode ( "^ | ^", $ array)
 
8) The known limitations on the use
There are no restrictions on use was found.

[RUSSIAN]
Модуль для добавочного функционала для полей с текстовые поля.
 
1) Описание
Модуль позволяет динамически добавлять любое количество телефонных номеров к любым записям,
а так же помечать их дополнительными атрибутами, такими как: основной, не звонить, личный, мобильный, рабочий, факс.
Модуль разработан полностью в upgrade safe стиле с поддержкой мультиязычности (в комплект включена русская и английская версия)

Атрибуты можно редактировать через административную часть SugarCRM : Редактор комбобоксов.
Возможные варианты храняться в комбобоксе: phone_type_dom. Редактирование комбобокса полностью в стиле SugarCRM.

В списке(listview) отображается только основной номер, если основной номер не задан, то первый.
 
 
2) Нововведения в системе поиска
Для данного типа поля решена проблема с поиском по телефонным номерам,  
т.к. телефоны могут заноситься в разных форматах разными пользователями
Например: +1 080 354-456-456, 38050-432 432 654,
то в стандартной версии поиск по телефонам усложняется.
В данной версии отдельно хранится так же номер телефона с удаленными разделителями всех типов,
пользователь теперь может свободно искать данные номера без подбора разделителей,
т.е теперь номер найдется по запросам 354456456, 050432432654, с какими бы разделителями он не создан в оригинале,
при этом можно точно также его найти и по оригинальному варианту с разделителями 38050-432 432 654.
 
Необходимо помнить, что так как у нас хранится несколько номеров в одной ячейке,
а также чтобы можно было искать по номерам телефонов без кодов стран и городов,
в строке поиска необходимо использовать символ % слева и справа, для поиска по вхождению подстроки.
Например: %354456456%, %38050-432 432 654% и т.д.
 
Если вариант указывания % в строке не устраивает, то можно как вариант настроить поиск по вхождению подстроки по умолчанию для всех полей,
для это в файле : /include/SearchForm/SearchForm2.php,
меняем строки (таких строк 2!)
$where .=  $db_field . " like '".$field_value.$like_char."'";
на
$where .=  $db_field . " like '".$like_char.$field_value.$like_char."'";
 
В SugarCRM 6.0. это строки номер 723 и 727  
 
3) Принцип работы модуля
Так как модуль разрабатывался как upgrade safe решения для любого модуля,
то был выбран наиболее простой вариант реализации, хранение всех данных в одной ячейке.
Данное хранение подобно варианту хранения MultiEnum значений в ЦРМ,  
где в качестве разделителя между данными тоже выступает ^,^.
 
При сохранении данные "сжимаются" в одно значение, при извлечении "разжимаются".
 
4) Установка
Модуль устанавливается стандартно через загрузчик модулей в административной части SugarCRM.
Полная upgrade safe совместимость с версиями SugarCRM выше 5.5.
Теоретически совместимость с любой версией начиная с 5.0. (Не тестировалась)
 
5) Использование
После установки в студии появляется новый тип поля ExtraPhone (В русской версии "расширенный телефон").
В любой модуль можно добавить поле данного типа.  
Также после этого данное поле можно добавлять в любой макет формы: Редактирование, Просмотр, Поиск, Список.
 
6) Совместимость с кастомными пользовательскими модулями (custom modules)
Полная совместимость с любыми кастомными модулями.
 
7) Работа через Soap
Можно работать с данным типом поля и через soap протокол, или же любой модуль работающий через soap протокол.
В этом случае "разжимание данных" программируется в модуле, который будет использовать это поле.
Реализуется в две строчки с помощью explode("^,^", $array), и explode("^|^", $array)
 
8) Известные ограничения на использование
Никаких ограничений на использование обнаружено не было.
