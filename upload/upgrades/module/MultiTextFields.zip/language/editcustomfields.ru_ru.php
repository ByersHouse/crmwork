<?php
$mod_strings['NEW_PHONE_IS_BY_DEFAULT'] = 'Значение телефона нельзя поставить по умолчанию';
$mod_strings['NEW_PHONE_IS_NOT_REPORTABLE'] = 'Поле с телефоном не доступно в отчетах';
$mod_strings['NEW_PHONE_IS_NOT_IMPORTABLE'] = 'Поле с телефон не импортируемое';
$mod_strings['NEW_PHONE_IS_NOT_MERGEABLE'] = 'Поле с телефоном не может использоваться при слиянии';
?>
