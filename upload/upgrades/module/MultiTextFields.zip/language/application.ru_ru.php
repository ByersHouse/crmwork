<?php
$app_strings['LBL_PHONE_MAIN'] = 'Основной';
$app_strings['LBL_PHONE_DONT_CALL'] = 'Не звонить';
$app_strings['LBL_TYPE_PHONE'] = 'Тип телефона';

$app_list_strings['phone_type_dom']['private'] = 'Личный';
$app_list_strings['phone_type_dom']['mobile'] = 'Мобильный';
$app_list_strings['phone_type_dom']['work'] = 'Рабочий';
$app_list_strings['phone_type_dom']['fax'] = 'Факс';

?>
