<?php
$mod_strings['fieldTypes']['multitextfield'] = 'Extended TextField';
?>
