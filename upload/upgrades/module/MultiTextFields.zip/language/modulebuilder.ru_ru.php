<?php
$mod_strings['fieldTypes']['multitextfield'] = 'Pасширенный Текстовое поле';
?>
