<?php

/**
 * function start before module start install
 */
function pre_install()
{
	if (check_already_install())
	{
		sugar_die('This module <b>already</b> installed. If you need install new version please uninstall current version <b style="color:red;">without delete database</b> and install new version of MultiTextFields.');
	}
}

/**
 * check if this module already install
 * @return bool
 * 	return True if module already installed
 */
function check_already_install()
{
	$uh = new UpgradeHistory();
	$uh->id_name = 'MultiTextFields';
	$result = $uh->checkForExisting($uh);

	if ($result != null)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}