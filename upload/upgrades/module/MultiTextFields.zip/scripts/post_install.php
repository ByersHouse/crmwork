<?php

// function fired after install module or after uninstall module
function post_install()
{
	if ($_REQUEST['mode'] == 'Install')
	{
		// install
		$GLOBALS['log']->info('Start MultiTextFields post install functions');

		print_welcome(); // print welcome text

		$GLOBALS['log']->info('End LiveReports post install functions');
	}
}


function print_welcome()
{
	global $current_language;

	$content = <<<EOQ
	<img src="http://sugartalk.ru/wp-content/themes/Estetica/images/logo.jpg"/>
	<p style="font-size: 14px;"><br>
	<span>Тел.: +7 (499) 999 12 14</span><br>
	<span>ICQ: 637516108</span><br>
	<span>Skype: SugarTalk.net</span><br>
	<span>E-mail: manager@sugartalk.net</span>
	</p>
	<p style="font-size: 14px;"><br>
	<span>Mods by William Kreider</span><br>
	<span>E-mail: madhatt30@yahoo.com</span><br>
	</p>
EOQ;

	echo $content;
}

?>
