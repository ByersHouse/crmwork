<?php
// created: 2017-09-12 12:59:04
$dictionary["bh_scr_status_history"]["fields"]["bh_scr_status_history_bh_scripts"] = array (
  'name' => 'bh_scr_status_history_bh_scripts',
  'type' => 'link',
  'relationship' => 'bh_scr_status_history_bh_scripts',
  'source' => 'non-db',
  'module' => 'bh_scripts',
  'bean_name' => 'bh_scripts',
  'side' => 'right',
  'vname' => 'LBL_BH_SCR_STATUS_HISTORY_BH_SCRIPTS_FROM_BH_SCRIPTS_TITLE',
);
