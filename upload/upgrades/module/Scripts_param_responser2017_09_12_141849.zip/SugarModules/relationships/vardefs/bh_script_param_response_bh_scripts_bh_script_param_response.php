<?php
// created: 2017-09-12 14:18:48
$dictionary["bh_script_param_response"]["fields"]["bh_script_param_response_bh_scripts"] = array (
  'name' => 'bh_script_param_response_bh_scripts',
  'type' => 'link',
  'relationship' => 'bh_script_param_response_bh_scripts',
  'source' => 'non-db',
  'module' => 'bh_scripts',
  'bean_name' => 'bh_scripts',
  'vname' => 'LBL_BH_SCRIPT_PARAM_RESPONSE_BH_SCRIPTS_FROM_BH_SCRIPTS_TITLE',
);
