<?php
// created: 2017-09-12 14:55:18
$dictionary["bh_Scripts_employee_comment"]["fields"]["bh_scripts_employee_comment_bh_scripts"] = array (
  'name' => 'bh_scripts_employee_comment_bh_scripts',
  'type' => 'link',
  'relationship' => 'bh_scripts_employee_comment_bh_scripts',
  'source' => 'non-db',
  'module' => 'bh_scripts',
  'bean_name' => 'bh_scripts',
  'vname' => 'LBL_BH_SCRIPTS_EMPLOYEE_COMMENT_BH_SCRIPTS_FROM_BH_SCRIPTS_TITLE',
);
