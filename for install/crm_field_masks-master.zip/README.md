# CRM Field Masks
### A field mask solution for SuiteCRM / SugarCRM CE

Docs can be found at: https://blasher.github.io/crm_field_masks/
